# foreign-aid-soft-power
Replication Code for: Foreign Aid and Soft Power: Great Power Competition in Africa in the Early 21st Century
